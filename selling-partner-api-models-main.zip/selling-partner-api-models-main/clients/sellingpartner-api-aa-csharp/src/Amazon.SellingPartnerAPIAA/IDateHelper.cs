﻿using System;
namespace Amazon.SellingPartnerAPIAA
{
    public interface IDateHelper
    {
        DateTime GetUtcNow();
    }
}
