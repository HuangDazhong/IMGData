﻿using System;
namespace Amazon.SellingPartnerAPIAA
{
    public class SigningDateHelper : IDateHelper
    {
        public DateTime GetUtcNow()
        {
            return DateTime.UtcNow;
        }
    }
}
