package com.amazon.SellingPartnerAPIAA;

public interface RateLimitConfiguration {

    Double getRateLimitPermit();

    Long getTimeOut();

}
